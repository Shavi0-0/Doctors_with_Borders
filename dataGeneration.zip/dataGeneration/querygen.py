import random
import itertools as i
import csv
import string
def main():
    hos,fl = hospital_queries()
    wa = ward_queries(fl)
    rq = room_queries()
    iq = Insurance_Policy_queries()
    con = cond_extract()
    pq,ssnP,nl = patient_queries()
    vq,ssn = visitor_queries(ssnP,nl)
    eq,opId,medID = employee_queries(ssn)
    oq = operational_queries(opId)
    mpq,care = medical_personal_queries(medID)
    cq = cares_for(care)
    ail = ailed_by()
    ab = i.chain(hos,wa,rq,con,iq,pq,ail,vq,eq,oq,mpq,cq)    
    sql_output(ab)


def hospital_queries():
    names = name_gen('hos')
    addressList = []
    with open('AddressData.csv',newline = '') as csvfile:
        reader = csv.reader(csvfile,delimiter=',', quotechar='|')
        for row in reader:
            addressList.append(', '.join(row))
    floorList = []
    for i in range(200):
        floorList.append(random.randint(25,50))
    queries = []
    for x in range(200):
        queries.append(f'INSERT INTO Hospital (`Name`,Address,Capacity,Num_of_Floors) VALUES ("{names[x]}","{addressList[x]}",{random.randint(100,5000)},{floorList[x]});\n')
    return queries,floorList


def ward_queries(fl):
    queries = []
    for x in range(200):
        special = name_gen('ward')
        for y in special:
            queries.append(f'INSERT INTO Ward (FHospital_ID,Speciality,Floor_Num,Capacity) VALUES ({x+1},"{y}",{random.randint(1,fl[x])},{random.randint(40,100)});\n')
    return queries

def room_queries():
    queries = []
    for x in range(400):
        for y in range(5): 
            queries.append(f'INSERT INTO Room (FWard_ID,Room_Num,Num_of_Beds,Capacity) VALUES ({x+1},{random.randint(1,500)},{random.randint(2,5)},{random.randint(10,20)});\n')
    return queries

def Insurance_Policy_queries():
    queries = []
    insurance_names = ['United Health','Kaiser Foundation','Anthem Inc.','Centene Corporation','Humana','CVS Health','CIGNA','Molina Healthcare','Independence Health Group','Guidewell Mutual Holding','High Mark Group','Blue Cross Blue Shield','Carefirst Inc.','MetroPolitan','HealthNet','Caresource','UPMC Health System','Point32Health','Wellmark','Health Partners']
    # print(len(insurance_names))
    for x in insurance_names:
        g=1000
        for y in range(10):
            queries.append(f'INSERT INTO Insurance_Policy (Company,Deductible) VALUES ("{x}",{g});\n')
            g+=1000
    return queries

def patient_queries():
    queries = []
    nameList = []
    with open('Name1.csv',newline='') as csvfile:
        reader = csv.reader(csvfile,delimiter=",",quotechar='|')
        for row in reader:
            nameList.append(''.join(row))
    with open('Name2.csv',newline='') as csvfile:
        reader = csv.reader(csvfile,delimiter=",",quotechar='|')
        for row in reader:
            nameList.append(''.join(row))
    with open('Name5.csv',newline='') as csvfile:
        reader = csv.reader(csvfile,delimiter=",",quotechar='|')
        for row in reader:
            nameList.append(''.join(row))
    with open('Name6.csv',newline='') as csvfile:
        reader = csv.reader(csvfile,delimiter=",",quotechar='|')
        for row in reader:
            nameList.append(''.join(row))
    i = 0
    newSet = set()
    while len(newSet) < 4000:
        newSet.add(random.randint(1000000000,2147483647))
    ssn_list = list(newSet)
    for x in range(2000):
        for y in range(2):
            queries.append(f'INSERT INTO patient (SSN,`Name`,Age,Admitted_Time,Checkout_Time,Expenses,FPolicy_ID,FRoom_ID) VALUES ({newSet.pop()},"{nameList[i]}",{random.randint(1,110)},CURRENT_TIMESTAMP,CURRENT_TIMESTAMP,{random.randint(100,1000000)},{random.randint(1,200)},{x+1});\n')
            i+=1
    return queries,ssn_list,nameList


def visitor_queries(ssn,nl):
    queries = []
    nameList = []
    combssn = []
    relationship = ['Parent','Sibling','Grandparent','Aunt','Uncle','Cousin','Niece','Nephew','Spouse','Child','Grandchild']
    with open('200Visitors.csv',newline='') as csvfile:
        reader = csv.reader(csvfile,delimiter=",",quotechar='|')
        for row in reader:
            nameList.append(''.join(row))
    i = 0
    newSet = set()
    while len(newSet) < 200:
        temp = random.randint(1000000000,2147483647)
        if not temp in ssn:
            newSet.add(temp)
    ssn_list = list(newSet)
    combssn.append(ssn_list)
    combssn.append(ssn)
    for x in range(200):
        for y in range(1):
                queries.append(f'INSERT INTO visitor (SSN,`Name`,Age,FPatient_ID,Patient_Relation,Number_of_times_visited,Alloted_Visit_Time,Arrival_Time,Departure_Time) VALUES ({newSet.pop()},"{nameList[i]}",{random.randint(1,110)},{random.randint(1,2000)},"{random.choice(relationship)}",{random.randint(1,10)},{random.randint(100,999)},CURRENT_TIMESTAMP,CURRENT_TIMESTAMP);\n')
                i+=1
    return queries,combssn

def employee_queries(ssnL):
    res = []
    #INSERT INTO `Employee` (SSN, `Name`, Age, Employee_ID, Salary, Job Title, PTO, Tenure, Supervisor_ID, FHospital_ID) VALUES (ssn, name, age, employee_id, salary, job_title, pto, tenure, supervisor_id, Fhospital_id)
    firstNameList = []
    lastNameList = []
    opList = []
    medList = []
    ssnSet = set() # set to keep track of generated SSNs
    opIDList = []
    medIDList =[]
    nameSet = set()

    # Read name list
    with open('FirstName.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=",", quotechar='|')
        for row in reader:
            firstNameList.append(''.join(row))

    with open('LastName.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=",", quotechar='|')
        for row in reader:
            lastNameList.append(''.join(row))

    # Read job list
    with open('OperationalJobTitles.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=",", quotechar='|')
        for row in reader:
            opList.append(''.join(row))

    with open('NurseTitle.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=",", quotechar='|')
        for row in reader:
            medList.append(''.join(row))

    with open('DoctorTitle.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=",", quotechar='|')
        for row in reader:
            medList.append(''.join(row))
    while len(nameSet)<10000:
        first = random.choice(firstNameList)
        last = random.choice(lastNameList)
        nameSet.add(f'{first} {last}')
    # Generate queries
    i = 1
    for hospital_id in range(1, 201):
        for employee in range(1, 50):
            while len(ssnSet) <1000: # keep generating new SSNs until a unique one is generated
                ssn = random.randint(1000000000, 2147483647)
                if ssn not in ssnL and ssn not in ssnSet:
                    ssnSet.add(ssn)


            
            age = random.randint(16, 85)
            if employee <25:
                salary = random.randint(42000, 70000)
                job_title = random.choice(opList)
                opIDList.append(i)
            else:
                salary = random.randint(70000, 300000)
                job_title = random.choice(medList)
                medIDList.append((i,hospital_id))
            # job_title = random.choice(jobList)

            pto = random.randint(0, 30)
            tenure = random.randint(0, 1)
            
            f_hospital_id = hospital_id
            query = f'INSERT INTO Employee (SSN, `Name`, Age, Salary, Job_Title, PTO, Tenure, FHospital_ID) VALUES ({ssn}, "{nameSet.pop()}", {age}, {salary}, {job_title}, {pto}, {tenure} ,{f_hospital_id});\n'
            res.append(query)
            i+=1
    for x in range(9800):
        query = f'UPDATE Employee set Supervisor_ID = {random.randint(1,9800)} where Employee_ID = {x+1};\n'
        res.append(query)
    return res,opIDList,medIDList

def operational_queries(opID):
    resp_list = []
    res = []
    with open('OperationalJobResposibility.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=",", quotechar='|')
        for row in reader:
            resp_list.append(''.join(row))
    
    for x in opID:
        query = f'INSERT INTO Operational_Staff (FEmployee_ID, Responsibility) VALUES ({x}, {random.choice(resp_list)});\n'
        res.append(query)
    return res

def medical_personal_queries(medID):
    res = []
    care = []
    #medical_personnel_degree = []
    license_list= set()
    # Read name list
    while len(license_list)< len(medID):
        license_list.add(''.join(random.choices(string.ascii_uppercase + string.digits, k=10)))
    
    medical_personnel_degree = ['Doctor of Medicine (MD)', 'Bachelor of Science in Nursing', 'Bachelor of Science in Biology', 'Bachelor of Science in Neurology', 'Bachelor of Science in Anesthesiology', 'Bachelor of Science in Radiology', 'Bachelor of Science in Nutrition and Health']
    medical_personnel_speciality = ['Pediatrics', 'Geriatrics', 'Neuro', 'Spine', 'Plastic', 'Optomology', 'OBGYN', 'Orthopedics', 'Cardiology', 'Primary Health', 'ER', 'General', 'Urology', 'ENT', 'Infectious Diseases', 'GastroIntestinal', 'NICU', 'Sports', 'Anesthesiology', 'Dermatology', 'Radiology']
    # Generate queries
    for x in medID:
        degree = random.choice(medical_personnel_degree)
        speciality = random.choice(medical_personnel_speciality)
        ward_id = (x[1]*2)-(random.randint(0,1))
        temp = license_list.pop()
        care.append((temp,ward_id))
        query = f"INSERT INTO medical_personnel (FEmployee_ID, License_Number, Degree, Speciality, FWard_ID) VALUES ({x[0]}, '{temp}', '{degree}', '{speciality}', {ward_id});\n"
        res.append(query)
    return res, care
    pass

def cares_for(care):
    res = []
    for x in range(len(care)):
        test = care[x][1]
        test = test*5
        testLow = test-4
        testHigh = test
        lowPatIDBound = (testLow*2)-1
        highPatIDBound = (testHigh*2)
        query = f"INSERT INTO Cares_For (FLicense_Number,FPatient_ID) VALUES ('{care[x][0]}',{random.randint(lowPatIDBound,highPatIDBound)});\n"
        res.append(query)
    return res
    pass

def cond_extract():
    clean_list = []
    with open('message.txt','r') as file:
        for line in file:
            if "INSERT INTO `Condition`" in str(line):
                clean_list.append(str(line))
    with open('output.sql','r') as file:
        for line in file:
            clean_list.append(str(line))
    with open('treated_by.sql','r') as file:
        for line in file:
            clean_list.append(str(line))

    
    return clean_list


def ailed_by():
    disease_list = []
    with open('Conditions.csv',newline = '') as csvfile:
        reader = csv.reader(csvfile,delimiter=',', quotechar='|')
        for row in reader:
            temp = row[0]
            if not '"' in temp:
                disease_list.append(temp)
    queries = []
    for x in range(4000):
      num_diseases = random.randint(1, 2)
      diseases = random.sample(disease_list, num_diseases)
      for disease in diseases:
            queries.append(f'INSERT INTO ailed_by (FPatient_ID, FMedical_Name) VALUES ({x+1}, "{disease}");\n')
    return queries



def name_gen(tab_type):
    colors = ['White','Yellow','Blue','Red','Green','Black','Brown','Ivory','Silver','Grey']
    animals = ['Eagle','Goose','Finch','Whale','Lamb','Steer','Goat','Swan','Llama','Lion']
    plants = ['Maple','Holly','Pine','Rose','Daisy','Lilac','Wisteria','Jasmine','Cypress','Clover']
    wards = ['Intensive Care','General']
    newSet = set()
    if tab_type == 'hos':
        while len(newSet) < 200:
            choice = random.randint(0,1)
            if choice == 0:
                name = f'{colors[random.randint(0,9)]} {animals[random.randint(0,9)]} Hospital'
                newSet.add(name)
            else:
                name = f'{colors[random.randint(0,9)]} {plants[random.randint(0,9)]} Hospital'
                newSet.add(name)
        return list(newSet)
    if tab_type == 'ward':
        while len(newSet) < 2:
            spec = random.choice(wards)
            newSet.add(spec)
        return list(newSet)
    pass

def sql_output(queries):
    filename = open('sql_queries.sql','w')
    # filename = open('sql_queries.txt','w')
    for x in queries:
        filename.write(x)
    filename.close()
    pass


if __name__ == "__main__":
    main()